import re
import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext

usuarios = []

# ---------------- FUNCIONES DE LÓGICA ---------------- #

def alta():
    nombre = simpledialog.askstring("Alta", "Nombre:")
    if not nombre:
        return

    edad = simpledialog.askstring("Alta", "Edad:")
    if not edad:
        return

    email = simpledialog.askstring("Alta", "Email:")
    if not email:
        return

    patron = r'^[\w\.-]+@[\w\.-]+\.\w+$'

    if re.match(patron, email):

        codigo = len(usuarios) + 1

        usuarios.append([nombre, edad, email, codigo])

        messagebox.showinfo(
            "Éxito",
            f"Usuario agregado.\nCódigo asignado: {codigo}"
        )

        actualizar_consulta()

    else:
        messagebox.showerror("Error", "Email inválido")


def baja():

    codigo_input = simpledialog.askinteger(
        "Baja",
        "Código a eliminar:"
    )

    if codigo_input is None:
        return

    encontrado = False

    for u in usuarios:

        if u[3] == codigo_input:

            usuarios.remove(u)

            messagebox.showinfo(
                "Éxito",
                "Usuario eliminado"
            )

            encontrado = True

            actualizar_consulta()

            break

    if not encontrado:
        messagebox.showwarning(
            "Atención",
            "Código no encontrado"
        )


def actualizar_consulta():

    txt_pantalla.config(state=tk.NORMAL)

    txt_pantalla.delete(1.0, tk.END)

    if not usuarios:

        txt_pantalla.insert(
            tk.END,
            "No hay usuarios registrados."
        )

    else:

        for u in usuarios:

            txt_pantalla.insert(
                tk.END,
                f"Cód: {u[3]} | Nombre: {u[0]} | Edad: {u[1]} | Email: {u[2]}\n"
            )

    txt_pantalla.config(state=tk.DISABLED)


def modificar():

    codigo_input = simpledialog.askinteger(
        "Modificar",
        "Código a modificar:"
    )

    if codigo_input is None:
        return

    encontrado = False

    for u in usuarios:

        if u[3] == codigo_input:

            encontrado = True

            nombre = simpledialog.askstring(
                "Modificar",
                "Nuevo nombre:",
                initialvalue=u[0]
            )

            if not nombre:
                return

            edad = simpledialog.askstring(
                "Modificar",
                "Nueva edad:",
                initialvalue=u[1]
            )

            if not edad:
                return

            email = simpledialog.askstring(
                "Modificar",
                "Nuevo email:",
                initialvalue=u[2]
            )

            if not email:
                return

            patron = r'^[\w\.-]+@[\w\.-]+\.\w+$'

            if re.match(patron, email):

                u[0] = nombre
                u[1] = edad
                u[2] = email

                messagebox.showinfo(
                    "Éxito",
                    "Usuario modificado"
                )

                actualizar_consulta()

            else:
                messagebox.showerror(
                    "Error",
                    "Email inválido"
                )

            break

    if not encontrado:

        messagebox.showwarning(
            "Atención",
            "Código no encontrado"
        )

# ---------------- CAMBIO DE COLORES ---------------- #

def cambiar_color(color_ventana, color_panel, color_boton, color_texto):

    ventana.config(bg=color_ventana)

    frame_botones.config(bg=color_panel)
    frame_pantalla.config(bg=color_panel)
    frame_colores.config(bg=color_panel)

    lbl_titulo.config(
        bg=color_panel,
        fg=color_texto
    )

    botones = [
        btn_alta,
        btn_baja,
        btn_modificar,
        btn_salir
    ]

    for boton in botones:

        boton.config(
            bg=color_boton,
            fg=color_texto,
            activebackground=color_ventana,
            activeforeground=color_texto
        )

# ---------------- INTERFAZ ---------------- #

ventana = tk.Tk()

ventana.title("Gestión de Usuarios")

ventana.geometry("700x450")

# Panel izquierdo
frame_botones = tk.Frame(
    ventana,
    padx=10,
    pady=10
)

frame_botones.pack(
    side=tk.LEFT,
    fill=tk.Y
)

btn_alta = tk.Button(
    frame_botones,
    text="1- Alta",
    width=15,
    command=alta
)

btn_alta.pack(pady=5)

btn_baja = tk.Button(
    frame_botones,
    text="2- Baja",
    width=15,
    command=baja
)

btn_baja.pack(pady=5)

btn_modificar = tk.Button(
    frame_botones,
    text="3- Modificar",
    width=15,
    command=modificar
)

btn_modificar.pack(pady=5)

btn_salir = tk.Button(
    frame_botones,
    text="4- Salir",
    width=15,
    fg="red",
    command=ventana.quit
)

btn_salir.pack(pady=20)

# ---------------- BOTONES DE COLORES ---------------- #

frame_colores = tk.Frame(frame_botones)

frame_colores.pack(pady=10)

tk.Label(
    frame_colores,
    text="Cambiar Tema",
    font=("Arial", 10, "bold")
).pack(pady=5)

tk.Button(
    frame_colores,
    text="Claro",
    width=12,
    bg="white",
    command=lambda: cambiar_color(
        "white",
        "#f0f0f0",
        "#d9d9d9",
        "black"
    )
).pack(pady=2)

tk.Button(
    frame_colores,
    text="Oscuro",
    width=12,
    bg="gray20",
    fg="white",
    command=lambda: cambiar_color(
        "#1e1e1e",
        "#2b2b2b",
        "#3c3f41",
        "white"
    )
).pack(pady=2)

tk.Button(
    frame_colores,
    text="Azul",
    width=12,
    bg="lightblue",
    command=lambda: cambiar_color(
        "#bde0fe",
        "#a2d2ff",
        "#89c2ff",
        "black"
    )
).pack(pady=2)

tk.Button(
    frame_colores,
    text="Verde",
    width=12,
    bg="lightgreen",
    command=lambda: cambiar_color(
        "#d8f3dc",
        "#b7e4c7",
        "#95d5b2",
        "black"
    )
).pack(pady=2)

tk.Button(
    frame_colores,
    text="Rosa",
    width=12,
    bg="pink",
    command=lambda: cambiar_color(
        "#ffc8dd",
        "#ffafcc",
        "#ff90b3",
        "black"
    )
).pack(pady=2)

# ---------------- PANEL DERECHO ---------------- #

frame_pantalla = tk.Frame(
    ventana,
    padx=10,
    pady=10
)

frame_pantalla.pack(
    side=tk.RIGHT,
    fill=tk.BOTH,
    expand=True
)

lbl_titulo = tk.Label(
    frame_pantalla,
    text="Lista de Usuarios:",
    font=("Arial", 10, "bold")
)

lbl_titulo.pack(anchor=tk.W)

txt_pantalla = scrolledtext.ScrolledText(
    frame_pantalla,
    wrap=tk.WORD,
    width=40,
    height=15
)

txt_pantalla.pack(
    fill=tk.BOTH,
    expand=True,
    pady=5
)

# Inicializar pantalla
actualizar_consulta()

# Tema inicial
cambiar_color(
    "white",
    "#f0f0f0",
    "#d9d9d9",
    "black"
)
# Ejecutar aplicación
ventana.mainloop() 